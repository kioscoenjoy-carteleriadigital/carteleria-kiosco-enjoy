/* global React */
// Kiosco Enjoy — App UI Kit components
// Lucide icons loaded from CDN (window.lucide). Icon re-renders on each pass.

const { useState, useEffect, useRef } = React;

function Icon({ name, size = 22, color, strokeWidth = 2, style }) {
  return (
    <span className="ke-icon" style={{ fontSize: size, color, ...style }}>
      <i data-lucide={name} style={{ "--sw": strokeWidth }}></i>
    </span>
  );
}

// ---- Logo (inline img to brand svg) ----
function Logo({ variant = "white", height = 30 }) {
  const src = { white: "../../assets/logo-white.svg", red: "../../assets/logo-red.svg", black: "../../assets/logo-black.svg" }[variant];
  return <img src={src} alt="Kiosco Enjoy" style={{ height, display: "block" }} />;
}

// ---- Buttons ----
function Button({ children, variant = "primary", size = "md", full, icon, onClick, style }) {
  return (
    <button className={`ke-btn ke-btn-${variant} ke-btn-${size}`} onClick={onClick}
      style={{ width: full ? "100%" : undefined, ...style }}>
      {icon && <Icon name={icon} size={size === "sm" ? 16 : 19} />}
      {children}
    </button>
  );
}

// ---- Top app header (location + bell) ----
function AppHeader({ address = "Av. San Martín 1240", onSearch }) {
  return (
    <header className="ke-appheader">
      <div className="ke-appheader-top">
        <Logo variant="white" height={26} />
        <button className="ke-icon-btn-ghost"><Icon name="bell" size={20} color="#fff" /></button>
      </div>
      <button className="ke-loc">
        <Icon name="map-pin" size={16} color="#fff" />
        <span className="ke-loc-label">Entregar en</span>
        <span className="ke-loc-addr">{address}</span>
        <Icon name="chevron-down" size={16} color="rgba(255,255,255,.8)" />
      </button>
      <div className="ke-search" onClick={onSearch}>
        <Icon name="search" size={18} color="var(--ink-500)" />
        <span>Buscar gaseosas, fiambres, snacks…</span>
      </div>
    </header>
  );
}

// ---- Bottom tab bar ----
function TabBar({ active, onChange, cartCount = 0 }) {
  const tabs = [
    { id: "home", icon: "house", label: "Inicio" },
    { id: "cats", icon: "layout-grid", label: "Categorías" },
    { id: "offers", icon: "flame", label: "Ofertas" },
    { id: "cart", icon: "shopping-cart", label: "Carrito" },
    { id: "account", icon: "user", label: "Cuenta" },
  ];
  return (
    <nav className="ke-tabbar">
      {tabs.map((t) => (
        <button key={t.id} className={`ke-tab ${active === t.id ? "is-active" : ""}`} onClick={() => onChange(t.id)}>
          <span className="ke-tab-ico">
            <Icon name={t.icon} size={23} />
            {t.id === "cart" && cartCount > 0 && <span className="ke-tab-badge">{cartCount}</span>}
          </span>
          <span className="ke-tab-label">{t.label}</span>
        </button>
      ))}
    </nav>
  );
}

// ---- Category pill ----
function CategoryChip({ label, active, onClick }) {
  return <button className={`ke-chip ${active ? "is-active" : ""}`} onClick={onClick}>{label}</button>;
}

// ---- Promo hero banner ----
function PromoBanner({ eyebrow, title, sub, cta, onClick }) {
  return (
    <div className="ke-promo" onClick={onClick}>
      <div className="ke-promo-glow"></div>
      <div className="ke-promo-body">
        <div className="ke-promo-eyebrow">{eyebrow}</div>
        <div className="ke-promo-title">{title}</div>
        <div className="ke-promo-sub">{sub}</div>
        {cta && <span className="ke-promo-cta">{cta} <Icon name="arrow-right" size={15} /></span>}
      </div>
      <div className="ke-promo-emoji">🔥</div>
    </div>
  );
}

// ---- Category tile (grid) ----
function CategoryTile({ emoji, label, onClick }) {
  return (
    <button className="ke-cattile" onClick={onClick}>
      <span className="ke-cattile-emoji">{emoji}</span>
      <span className="ke-cattile-label">{label}</span>
    </button>
  );
}

// ---- Product card ----
function ProductCard({ product, qty = 0, onAdd, onRemove }) {
  return (
    <div className="ke-prod">
      <div className="ke-prod-photo">
        <span className="ke-prod-emoji">{product.emoji}</span>
        {product.flag && <span className="ke-prod-flag">{product.flag}</span>}
      </div>
      <div className="ke-prod-name">{product.name}</div>
      <div className="ke-prod-cat">{product.cat}</div>
      <div className="ke-prod-foot">
        <span className="ke-price">${product.price.toLocaleString("es-AR")}</span>
        {qty === 0 ? (
          <button className="ke-add" onClick={() => onAdd(product)}><Icon name="plus" size={20} color="#fff" /></button>
        ) : (
          <div className="ke-stepper">
            <button onClick={() => onRemove(product)}><Icon name="minus" size={16} color="#fff" /></button>
            <span>{qty}</span>
            <button onClick={() => onAdd(product)}><Icon name="plus" size={16} color="#fff" /></button>
          </div>
        )}
      </div>
    </div>
  );
}

// ---- Section header ----
function SectionHead({ title, action }) {
  return (
    <div className="ke-sechead">
      <h2>{title}</h2>
      {action && <button className="ke-link">{action} <Icon name="chevron-right" size={15} /></button>}
    </div>
  );
}

Object.assign(window, {
  Icon, Logo, Button, AppHeader, TabBar, CategoryChip,
  PromoBanner, CategoryTile, ProductCard, SectionHead,
});
