/* global React, AppHeader, TabBar, CategoryChip, PromoBanner, CategoryTile, ProductCard, SectionHead, Button, Icon, Logo */
const { useState, useEffect } = React;

const CATS = [
  { emoji: "🥤", label: "Bebidas" },
  { emoji: "🍺", label: "Cervezas" },
  { emoji: "🧀", label: "Fiambrería" },
  { emoji: "🥛", label: "Lácteos" },
  { emoji: "🍪", label: "Galletitas" },
  { emoji: "🍬", label: "Golosinas" },
  { emoji: "🧴", label: "Limpieza" },
  { emoji: "🧊", label: "Hielo y leña" },
];

const PRODUCTS = [
  { id: 1, name: "Coca-Cola 2.25L retornable", cat: "Bebidas", price: 2150, emoji: "🥤", flag: "2x1", c: "Bebidas" },
  { id: 2, name: "Quilmes Clásica 1L", cat: "Cervezas", price: 1890, emoji: "🍺", flag: "OFERTA", c: "Cervezas" },
  { id: 3, name: "Jamón cocido La Serenísima 100g", cat: "Fiambrería", price: 1650, emoji: "🧀", c: "Fiambrería" },
  { id: 4, name: "Leche entera La Serenísima 1L", cat: "Lácteos", price: 1320, emoji: "🥛", c: "Lácteos" },
  { id: 5, name: "Galletitas Bagley surtidas", cat: "Galletitas", price: 980, emoji: "🍪", c: "Galletitas" },
  { id: 6, name: "Alfajor Arcor triple", cat: "Golosinas", price: 720, emoji: "🍫", flag: "3x2", c: "Golosinas" },
  { id: 7, name: "Pepsi 1.5L", cat: "Bebidas", price: 1750, emoji: "🥤", c: "Bebidas" },
  { id: 8, name: "Hielo en cubos 3kg", cat: "Hielo y leña", price: 1900, emoji: "🧊", c: "Hielo y leña" },
  { id: 9, name: "Schneider lata 473ml", cat: "Cervezas", price: 1100, emoji: "🍺", flag: "OFERTA", c: "Cervezas" },
  { id: 10, name: "Detergente Magistral 750ml", cat: "Limpieza", price: 2480, emoji: "🧴", c: "Limpieza" },
];

function Money({ v }) { return <span>${v.toLocaleString("es-AR")}</span>; }

function App() {
  const [tab, setTab] = useState("home");
  const [cat, setCat] = useState("Todo");
  const [cart, setCart] = useState({});
  const [toast, setToast] = useState(null);
  const [checkout, setCheckout] = useState(false);

  useEffect(() => { window.lucide && window.lucide.createIcons(); });
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(null), 1800); return () => clearTimeout(t); }, [toast]);

  const add = (p) => { setCart((c) => ({ ...c, [p.id]: (c[p.id] || 0) + 1 })); setToast(`${p.name.split(" ").slice(0, 2).join(" ")} agregado`); };
  const remove = (p) => setCart((c) => { const n = { ...c }; if (n[p.id] > 1) n[p.id]--; else delete n[p.id]; return n; });
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  const total = Object.entries(cart).reduce((a, [id, q]) => a + PRODUCTS.find((p) => p.id === +id).price * q, 0);

  const filtered = cat === "Todo" ? PRODUCTS : PRODUCTS.filter((p) => p.c === cat);

  const goTab = (t) => { setCheckout(false); setTab(t); };

  let screen;
  if (checkout) {
    screen = <ConfirmScreen onDone={() => { setCart({}); setCheckout(false); setTab("home"); }} />;
  } else if (tab === "home") {
    screen = <HomeScreen {...{ cart, add, remove, setTab, setCat }} />;
  } else if (tab === "cats") {
    screen = <BrowseScreen {...{ cat, setCat, filtered, cart, add, remove }} />;
  } else if (tab === "offers") {
    screen = <OffersScreen {...{ cart, add, remove }} />;
  } else if (tab === "cart") {
    screen = <CartScreen {...{ cart, total, count, add, remove, onCheckout: () => setCheckout(true), goShop: () => setTab("cats") }} />;
  } else {
    screen = <AccountScreen />;
  }

  return (
    <div className="ke-phone">
      <div className="ke-screen">{screen}</div>
      {toast && <div className="ke-toast"><Icon name="check-circle-2" size={18} color="var(--success)" />{toast}</div>}
      <TabBar active={checkout ? "cart" : tab} onChange={goTab} cartCount={count} />
    </div>
  );
}

function HomeScreen({ cart, add, remove, setTab, setCat }) {
  return (
    <div>
      <AppHeader onSearch={() => setTab("cats")} />
      <div style={{ padding: "16px 0 0" }}>
        <div className="ke-pad" style={{ paddingBottom: 0 }}>
          <PromoBanner eyebrow="Combo previa" title="6 Quilmes + 2 papas" sub="Armá tu previa y pagá por la app. Solo este finde."
            cta="Ver combo" onClick={() => setTab("offers")} />
        </div>
        <SectionHead title="Categorías" />
        <div className="ke-pad" style={{ paddingTop: 0 }}>
          <div className="ke-catgrid">
            {CATS.map((c) => <CategoryTile key={c.label} emoji={c.emoji} label={c.label} onClick={() => { setCat(c.label); setTab("cats"); }} />)}
          </div>
        </div>
        <SectionHead title="Más pedidos" action="Ver todo" />
        <div className="ke-pad" style={{ paddingTop: 0, paddingBottom: 28 }}>
          <div className="ke-prodgrid">
            {PRODUCTS.slice(0, 6).map((p) => <ProductCard key={p.id} product={p} qty={cart[p.id] || 0} onAdd={add} onRemove={remove} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionHead({ title, action, onAction }) {
  return (
    <div className="ke-sechead ke-pad" style={{ paddingBottom: 0 }}>
      <h2>{title}</h2>
      {action && <button className="ke-link" onClick={onAction}>{action} <Icon name="chevron-right" size={15} /></button>}
    </div>
  );
}

function BrowseScreen({ cat, setCat, filtered, cart, add, remove }) {
  const cats = ["Todo", ...CATS.map((c) => c.label)];
  return (
    <div>
      <AppHeader />
      <div style={{ paddingTop: 14 }}>
        <div className="ke-chips">
          {cats.map((c) => <CategoryChip key={c} label={c} active={cat === c} onClick={() => setCat(c)} />)}
        </div>
        <div className="ke-pad" style={{ paddingTop: 0, paddingBottom: 28 }}>
          <div className="ke-prodgrid">
            {filtered.map((p) => <ProductCard key={p.id} product={p} qty={cart[p.id] || 0} onAdd={add} onRemove={remove} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

function OffersScreen({ cart, add, remove }) {
  const offers = PRODUCTS.filter((p) => p.flag);
  return (
    <div>
      <AppHeader />
      <div className="ke-pad">
        <PromoBanner eyebrow="🔥 Ofertas de la semana" title="Hasta 25% OFF" sub="En bebidas, cervezas y golosinas seleccionadas." />
        <div className="ke-prodgrid" style={{ marginTop: 4 }}>
          {offers.map((p) => <ProductCard key={p.id} product={p} qty={cart[p.id] || 0} onAdd={add} onRemove={remove} />)}
        </div>
      </div>
    </div>
  );
}

function CartScreen({ cart, total, count, add, remove, onCheckout, goShop }) {
  const lines = Object.entries(cart).map(([id, q]) => ({ p: PRODUCTS.find((x) => x.id === +id), q }));
  if (count === 0) {
    return (
      <div>
        <div className="ke-acct-head"><Logo variant="white" height={28} /></div>
        <div className="ke-empty">
          <div className="ke-empty-emoji">🛒</div>
          <h3>Tu changuito está vacío</h3>
          <p>Sumá productos y armá tu pedido.</p>
          <div style={{ marginTop: 18 }}><Button variant="primary" onClick={goShop}>Ver productos</Button></div>
        </div>
      </div>
    );
  }
  return (
    <div style={{ position: "relative", minHeight: "100%" }}>
      <div className="ke-acct-head"><Logo variant="white" height={28} /><div style={{ marginLeft: "auto", fontFamily: "var(--font-display)", fontWeight: 800 }}>Tu pedido</div></div>
      <div className="ke-pad" style={{ paddingBottom: 200 }}>
        {lines.map(({ p, q }) => (
          <div className="ke-cartline" key={p.id}>
            <div className="ke-cartline-emoji">{p.emoji}</div>
            <div className="ke-cartline-info">
              <div className="ke-cartline-name">{p.name}</div>
              <div className="ke-cartline-price"><Money v={p.price * q} /></div>
            </div>
            <div className="ke-stepper">
              <button onClick={() => remove(p)}><Icon name="minus" size={16} color="#fff" /></button>
              <span>{q}</span>
              <button onClick={() => add(p)}><Icon name="plus" size={16} color="#fff" /></button>
            </div>
          </div>
        ))}
      </div>
      <div className="ke-cartbar">
        <div className="ke-cartbar-row">
          <span style={{ color: "var(--fg2)", fontWeight: 600 }}>Total ({count} ítems)</span>
          <span className="ke-cartbar-total"><Money v={total} /></span>
        </div>
        <Button variant="primary" full onClick={onCheckout}>Confirmar pedido</Button>
      </div>
    </div>
  );
}

function ConfirmScreen({ onDone }) {
  return (
    <div>
      <div className="ke-acct-head"><Logo variant="white" height={28} /></div>
      <div className="ke-confirm">
        <div className="ke-confirm-badge"><Icon name="check" size={46} strokeWidth={3} /></div>
        <h2>¡Pedido confirmado!</h2>
        <p>Te avisamos cuando esté en camino.<br />Llega en aprox. 20–30 min.</p>
        <div style={{ marginTop: 24 }}><Button variant="ghost" onClick={onDone}>Volver al inicio</Button></div>
      </div>
    </div>
  );
}

function AccountScreen() {
  const items = [
    { icon: "package", label: "Mis pedidos" },
    { icon: "map-pin", label: "Mis direcciones" },
    { icon: "credit-card", label: "Medios de pago" },
    { icon: "printer", label: "Servicios: impresión, fotos, anillados" },
    { icon: "heart", label: "Favoritos" },
    { icon: "settings", label: "Configuración" },
  ];
  return (
    <div>
      <div className="ke-acct-head">
        <div className="ke-avatar">MV</div>
        <div><div className="ke-acct-name">Martín Vega</div><div className="ke-acct-sub">martin.vega@mail.com</div></div>
      </div>
      <div className="ke-list">
        {items.map((it) => (
          <div className="ke-listitem" key={it.label}>
            <span className="ke-listitem-ico"><Icon name={it.icon} size={20} /></span>
            <span className="ke-listitem-label">{it.label}</span>
            <Icon name="chevron-right" size={18} color="var(--ink-400)" />
          </div>
        ))}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
