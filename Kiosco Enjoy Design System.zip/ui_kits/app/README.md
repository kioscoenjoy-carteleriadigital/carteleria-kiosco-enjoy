# Kiosco Enjoy — App UI Kit

High-fidelity prototype of the **Kiosco Enjoy ordering app** (mobile, Spanish/rioplatense). Customers browse categories, see combos & ofertas, fill a *changuito* (cart) and confirm a pedido. This is a cosmetic recreation — state is local React, no backend.

## Run
Open `index.html`. The phone mock is interactive: navigate the bottom tabs (Inicio · Categorías · Ofertas · Carrito · Cuenta), tap **+** to add products, adjust quantities, and **Confirmar pedido** to see the confirmation screen.

## Files
| File | Contents |
|---|---|
| `index.html` | Loads React + Babel + Lucide + brand CSS, mounts the app |
| `app.css` | All kit styles (phone frame, header, tab bar, cards, cart, etc.) |
| `components.jsx` | Reusable presentational components (exported to `window`) |
| `app.jsx` | Screens + data + state (Home, Browse, Offers, Cart, Confirm, Account) |

## Components (`components.jsx`)
- **`Icon`** — Lucide icon wrapper (`name`, `size`, `strokeWidth`). Re-rendered via `lucide.createIcons()` each pass.
- **`Logo`** — brand wordmark (`variant`: white/red/black).
- **`Button`** — `variant`: primary / dark / ghost; `size`: md/sm; `full`, `icon`.
- **`AppHeader`** — red header with logo, location row, search field.
- **`TabBar`** — bottom nav with cart badge.
- **`CategoryChip`** — pill filter.
- **`PromoBanner`** — dark hero promo with red glow.
- **`CategoryTile`** — emoji + label grid tile.
- **`ProductCard`** — photo slot, flag, price, add/stepper.
- **`SectionHead`** — title + optional action link.

## Design notes
- Mobile-first, 390px. Fixed red `AppHeader` (sticky) + fixed bottom `TabBar`.
- Coke Red drives CTAs, header, badges; Black C for the promo hero; Brilliant White page.
- Prices in Exo 2 ExtraBold Italic. Add/stepper controls are solid red.
- Product photos are **emoji placeholders** — swap for real product photography (bright, on white) in production.
- Icons: **Lucide** via CDN (`window.lucide`). See README → ICONOGRAPHY.
