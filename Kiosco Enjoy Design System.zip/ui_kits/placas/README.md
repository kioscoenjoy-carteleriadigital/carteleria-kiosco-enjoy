# Kiosco Enjoy — Placas & Cartelera Kit

Templates for the brand's **social-media promo graphics (*placas*)** and the **storefront poster board (*cartelera*)**. These are the day-to-day marketing surfaces Kiosco Enjoy publishes.

## Run
Open `index.html` — shows all templates scaled to fit. Each is authored at real export size (square `1080×1080`, story `1080×1920`) and scaled down with CSS `transform` for preview.

## Templates (`placas.jsx`)
| Component | Format | Use |
|---|---|---|
| `PlacaOferta` | 1080×1080 | Single-product offer — red bg, product photo slot, white price burst |
| `PlacaCombo` | 1080×1080 | Combo/promo — dark bg, red glow, struck-through + combo price, yellow accent |
| `PlacaConcurso` | 1080×1920 story | Contest/giveaway — CTA to follow & tag |
| `PlacaCartelera` | 1080×1080 | Storefront price-list poster — light bg, red headline, ruled price rows |
| `PlacaFotoOferta` | 1080×1080 | **Foto real de fondo** — full-bleed photo (drag-drop slot) + protection gradient + overlay price |
| `PlacaFotoStory` | 1080×1920 story | **Foto real de fondo** — photo slot + gradient + headline + CTA |

### Foto-background variants
`PlacaFotoOferta` / `PlacaFotoStory` use an `<image-slot>`: **arrastrá tu propia foto** sobre el recuadro y queda de fondo. A dark **protection gradient** keeps the white headline and price legible over any photo. Use bright, well-lit product shots. (Note: drop persistence across reload is reliable when the page is served from the project root; inside the kit folder the drop is per-session — for production, place a copy at root or bake in a `src`.)

## Brand rules applied
- Logo locked to a corner with clear space; white logo on red/dark, red logo on light.
- Headlines in Exo 2 ExtraBold **Italic** echoing the logo slant; price bursts/flags often rotated ~7°.
- Coke Red is the dominant field; **promo yellow `#FFD400`** is the only secondary pop (tags, combo highlight).
- Emoji allowed here (🔥🧊🍻🎉🎁) — this is the one surface where they belong.
- Product imagery = **emoji placeholders**; swap for cut-out product photography (PNG on transparent) for production exports.

## Exporting
To produce a real asset, render a single template at full `1080` scale (remove the `transform`) and screenshot, or hand to a designer as a spec.
