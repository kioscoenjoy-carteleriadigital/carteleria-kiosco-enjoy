/* global React */
const PLOGO_W = "../../assets/logo-white.svg";
const PLOGO_R = "../../assets/logo-red.svg";

// ---- 1. OFERTA (square 1080) — red bg, product + price burst ----
function PlacaOferta() {
  return (
    <div className="placa" style={{ background: "var(--coke-red)" }}>
      <div className="p" style={{ top: 56, left: 56 }}><img className="placa-logo" src={PLOGO_W} /></div>
      <div className="p" style={{ top: 60, right: 56 }}>
        <span className="eyebrow-tag">OFERTA</span>
      </div>
      <div className="p" style={{ top: 280, left: 56, right: 56 }}>
        <div className="big-italic" style={{ fontSize: 130 }}>Coca-Cola<br />2.25L</div>
        <div style={{ color: "rgba(255,255,255,.85)", fontWeight: 600, fontStyle: "italic", fontSize: 40, marginTop: 14 }}>Retornable · bien fría 🧊</div>
      </div>
      <div className="p diag" style={{ bottom: 110, right: 56 }}>
        <div className="price-tag">
          <span className="pt-eyebrow">SOLO</span>
          <span className="pt-price">$2.150</span>
          <span className="pt-unit">2.25L</span>
          <span className="pt-hole"></span>
        </div>
      </div>
      <div className="p" style={{ left: 60, bottom: 150, fontSize: 240, lineHeight: 1 }}>🥤</div>
      <div className="p" style={{ left: 56, bottom: 56, color: "#fff", fontWeight: 700, fontSize: 32 }}>Pedilo por la app · @kioscoenjoy</div>
    </div>
  );
}

// ---- 2. COMBO (square 1080) — dark bg, yellow accents ----
function PlacaCombo() {
  return (
    <div className="placa" style={{ background: "var(--black-c)" }}>
      <div className="p" style={{ width: 620, height: 620, right: -160, top: -160, background: "var(--coke-red)", borderRadius: "50%", filter: "blur(4px)", opacity: .65 }}></div>
      <div className="p" style={{ top: 56, left: 56 }}><img className="placa-logo" src={PLOGO_W} /></div>
      <div className="p" style={{ top: 240, left: 56 }}>
        <div style={{ color: "var(--promo)", fontWeight: 800, fontStyle: "italic", fontSize: 46, letterSpacing: ".02em" }}>🔥 COMBO PREVIA</div>
        <div className="big-italic" style={{ fontSize: 118, marginTop: 12 }}>6 Quilmes<br /><span style={{ color: "var(--promo)" }}>+ 2 papas</span></div>
      </div>
      <div className="p" style={{ left: 56, bottom: 230, display: "flex", alignItems: "baseline", gap: 24 }}>
        <span style={{ color: "rgba(255,255,255,.55)", fontWeight: 700, fontStyle: "italic", fontSize: 56, textDecoration: "line-through" }}>$11.500</span>
        <span style={{ color: "#fff", fontWeight: 800, fontStyle: "italic", fontSize: 150 }}>$8.990</span>
      </div>
      <div className="p" style={{ left: 56, right: 56, bottom: 80 }}>
        <span style={{ background: "var(--coke-red)", color: "#fff", fontWeight: 800, fontStyle: "italic", fontSize: 44, padding: "22px 44px", borderRadius: 999 }}>Pedí ahora 👉 app</span>
      </div>
      <div className="p" style={{ right: 70, bottom: 360, fontSize: 220 }}>🍻</div>
    </div>
  );
}

// ---- 3. CONCURSO (story 1080x1920) — contest ----
function PlacaConcurso() {
  return (
    <div className="placa" style={{ background: "var(--coke-red)" }}>
      <div className="p" style={{ top: 80, left: 0, right: 0, textAlign: "center" }}><img className="placa-logo" src={PLOGO_W} style={{ height: 90 }} /></div>
      <div className="p" style={{ top: 360, left: 70, right: 70, textAlign: "center" }}>
        <span className="eyebrow-tag">SORTEO</span>
        <div className="big-italic" style={{ fontSize: 150, marginTop: 40 }}>Ganá un<br />combo<br />de previa</div>
      </div>
      <div className="p" style={{ top: 1040, left: 90, right: 90, color: "#fff", fontWeight: 600, fontStyle: "italic", fontSize: 50, textAlign: "center", lineHeight: 1.35 }}>
        Seguinos, dale ❤️ y etiquetá<br />a 2 amigos para participar.
      </div>
      <div className="p" style={{ left: 110, right: 110, bottom: 260, textAlign: "center" }}>
        <div style={{ background: "#fff", color: "var(--coke-red)", fontWeight: 800, fontStyle: "italic", fontSize: 60, padding: "30px 0", borderRadius: 999 }}>@kioscoenjoy</div>
      </div>
      <div className="p" style={{ left: 0, right: 0, bottom: 120, textAlign: "center", color: "rgba(255,255,255,.8)", fontWeight: 600, fontSize: 38 }}>Sorteo el 30/06 · Solo zona de reparto</div>
      <div className="p" style={{ left: 70, top: 980, fontSize: 150 }}>🎉</div>
      <div className="p" style={{ right: 70, top: 980, fontSize: 150 }}>🎁</div>
    </div>
  );
}

// ---- 4. CARTELERA (poster, square 1080) — high-contrast storefront sign ----
function PlacaCartelera() {
  return (
    <div className="placa" style={{ background: "var(--brilliant-white)" }}>
      <div className="p" style={{ top: 56, left: 56 }}><img className="placa-logo sm" src={PLOGO_R} /></div>
      <div className="p" style={{ top: 56, right: 56, background: "var(--black-c)", color: "#fff", fontWeight: 800, fontStyle: "italic", fontSize: 34, padding: "12px 26px", borderRadius: 8 }}>HOY</div>
      <div className="p" style={{ top: 300, left: 56, right: 56 }}>
        <div style={{ color: "var(--coke-red)", fontWeight: 800, fontStyle: "italic", fontSize: 110, lineHeight: .95 }}>OFERTAS<br />DE LA<br />SEMANA</div>
      </div>
      <div className="p" style={{ left: 56, right: 56, bottom: 90 }}>
        <Row t="Quilmes 1L" p="$1.890" flag="2x1" />
        <Row t="Leche La Serenísima 1L" p="$1.320" />
        <Row t="Hielo 3kg" p="$1.900" flag="🧊" />
      </div>
    </div>
  );
}
function Row({ t, p, flag }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 24, borderBottom: "3px solid var(--ink-300)", padding: "22px 0" }}>
      <span style={{ flex: 1, fontWeight: 700, fontStyle: "italic", fontSize: 52, color: "var(--black-c)" }}>{t}</span>
      {flag && <span style={{ background: "var(--promo)", color: "var(--black-c)", fontWeight: 800, fontStyle: "italic", fontSize: 34, padding: "6px 18px", borderRadius: 8 }}>{flag}</span>}
      <span style={{ fontWeight: 800, fontStyle: "italic", fontSize: 64, color: "var(--coke-red)" }}>{p}</span>
    </div>
  );
}

// ---- 5. OFERTA con FOTO (square 1080) — full-bleed photo + protection gradient ----
function PlacaFotoOferta() {
  return (
    <div className="placa">
      <image-slot id="placa-foto-oferta" shape="rect" fit="cover"
        placeholder="Arrastrá una foto de producto"
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}></image-slot>
      <div className="p placa-grad-bottom"></div>
      <div className="p" style={{ top: 56, left: 56 }}><img className="placa-logo" src={PLOGO_W} /></div>
      <div className="p diag" style={{ top: 70, right: 56 }}><span className="eyebrow-tag">OFERTA</span></div>
      <div className="p" style={{ left: 56, right: 56, bottom: 220 }}>
        <div className="big-italic" style={{ fontSize: 96 }}>Cerveza<br />bien fría</div>
      </div>
      <div className="p" style={{ left: 56, bottom: 90, display: "flex", alignItems: "baseline", gap: 20 }}>
        <span style={{ color: "rgba(255,255,255,.7)", fontWeight: 700, fontStyle: "italic", fontSize: 44 }}>desde</span>
        <span style={{ color: "#fff", fontWeight: 800, fontStyle: "italic", fontSize: 130, lineHeight: 1 }}>$1.100</span>
      </div>
      <div className="p" style={{ right: 60, bottom: 110, background: "var(--coke-red)", color: "#fff", fontWeight: 800, fontStyle: "italic", fontSize: 40, padding: "18px 34px", borderRadius: 999 }}>Pedí por la app</div>
    </div>
  );
}

// ---- 6. STORY con FOTO (1080x1920) — photo bg + bold overlay ----
function PlacaFotoStory() {
  return (
    <div className="placa">
      <image-slot id="placa-foto-story" shape="rect" fit="cover"
        placeholder="Arrastrá una foto"
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}></image-slot>
      <div className="p placa-grad-full"></div>
      <div className="p" style={{ top: 80, left: 0, right: 0, textAlign: "center" }}><img className="placa-logo" src={PLOGO_W} style={{ height: 84 }} /></div>
      <div className="p diag" style={{ top: 300, left: 90 }}><span className="eyebrow-tag">NUEVO</span></div>
      <div className="p" style={{ top: 1180, left: 90, right: 90 }}>
        <div className="big-italic" style={{ fontSize: 150 }}>Tu kiosco,<br />ahora en tu<br />celular</div>
        <div style={{ color: "rgba(255,255,255,.85)", fontWeight: 600, fontStyle: "italic", fontSize: 48, marginTop: 24 }}>Pedí y pagá desde la app 📲</div>
      </div>
      <div className="p" style={{ left: 90, right: 90, bottom: 150 }}>
        <div style={{ background: "var(--coke-red)", color: "#fff", fontWeight: 800, fontStyle: "italic", fontSize: 56, padding: "32px 0", borderRadius: 999, textAlign: "center" }}>Descargá la app 👉</div>
      </div>
    </div>
  );
}

Object.assign(window, { PlacaOferta, PlacaCombo, PlacaConcurso, PlacaCartelera, PlacaFotoOferta, PlacaFotoStory });
