---
name: kiosco-enjoy-design
description: Use this skill to generate well-branded interfaces and assets for Kiosco Enjoy, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference
- **Colors:** Coke Red `#F40000` (primary), Black C `#2D2926` (warm ink), Brilliant White `#F0F0F1` (page). Promo yellow `#FFD400` as secondary pop. Full tokens in `colors_and_type.css`.
- **Type:** Exo 2 (self-hosted in `fonts/`). Headlines & prices in ExtraBold **Italic**; body Regular/Medium.
- **Logos:** `assets/logo-{red,white,black}.svg`. White on red/dark, red on light.
- **Icons:** Lucide (CDN), 2px stroke. Emoji only on social placas.
- **UI kits:** `ui_kits/app/` (ordering app), `ui_kits/placas/` (social + cartelera).
- **Voice:** Argentine Spanish, *vos*, warm/energetic, lead with the deal. See README → CONTENT FUNDAMENTALS.
