# Kiosco Enjoy — Design System

**Kiosco Enjoy** is a neighborhood convenience store (*tienda de cercanía / kiosco-almacén*) in Argentina. It sells pantry and grocery staples, soft drinks, beer & alcoholic beverages, deli & cold cuts (*fiambrería*), dairy (*lácteos*), canned goods, cookies, candy, snacks, baked goods, ice, firewood & charcoal (*leña y carbón*), and cleaning & personal-care products. It stocks recognized brands — **Coca-Cola, Quilmes, Schneider, Arcor, La Serenísima, Pepsi, Rumipal** — and builds its own **combos y promociones**.

The store leans on **personalized service** and a drive to feel **modern, clean but eye-catching, simple but novel** — they actively want technology to set them apart. They are **building an ordering app** so customers can shop and pay through it. They also run **annex services on request**: note/document printing, photo printing, ring-binding (*anillados*), etc. They are active on **social media** with promo/contest graphics (*placas*), and keep a **physical poster board (*cartelera*)** at the storefront for offers.

> This design system gives design agents everything needed to produce on-brand Kiosco Enjoy assets: the ordering app UI, social promo *placas*, storefront posters, price tags, and combo graphics.

---

## Brand at a glance

| | |
|---|---|
| **Primary color** | Coke Red `#F40000` ("Rojo Coke") |
| **Dark** | Pantone Black C `#2D2926` (warm near-black) |
| **Light** | Pantone Brilliant White `#F0F0F1` (never pure white) |
| **Typeface** | **Exo 2** (self-hosted, full weight range) |
| **Logo** | Stacked italic wordmark "Kiosco / Enjoy", Exo 2 ExtraBold Italic |
| **Personality** | Modern, bold, friendly, energetic, trustworthy neighborhood store |

---

## CONTENT FUNDAMENTALS

**Language:** Argentine Spanish (rioplatense). Use *vos* implicitly through imperatives (*pedí, llevá, sumá, enterate*), not *tú*. Currency is the Argentine peso, written `$1.250` (dot thousands separator, no decimals on shelf prices).

**Tone:** Warm, direct, energetic — the voice of a friendly *kiosquero* who knows you. Confident and promotional without shouting in ALL CAPS body copy. Optimistic and a little playful ("Enjoy" is literal — enjoyment is the promise).

**Person:** Speak **to** the customer in second person (*vos / tu pedido / llevate*). The store refers to itself as **"Kiosco Enjoy"** or **"nosotros"**, never first-person singular.

**Casing:**
- **Headlines & promos:** Title or sentence case in heavy italic. Reserve full UPPERCASE for short punchy labels — `OFERTA`, `COMBO`, `2x1`, `NUEVO`, eyebrows, and price-tag flags.
- **Body:** Sentence case.
- **Eyebrows/labels:** UPPERCASE with positive letter-spacing (`0.04em`).

**Numbers & offers:** Promotions are the hero — lead with the deal. `2x1`, `3x2`, `25% OFF`, `COMBO $X`, `LLEVÁ 3 PAGÁ 2`. Prices set in Exo 2 ExtraBold Italic so they feel fast and loud.

**Emoji:** Used **sparingly** on social *placas* only (🛒 🔥 🧊 🍻 🎉), never in app UI chrome or formal materials. Prefer real iconography over emoji inside the product.

**Example copy:**
- Promo placa: *"COMBO PREVIA 🔥 — 6 Quilmes + 2 papas a $X. Pedilo por la app."*
- App empty cart: *"Tu changuito está vacío. Sumá productos y armá tu pedido."*
- CTA buttons: *"Pedir ahora"*, *"Agregar al carrito"*, *"Ver combos"*, *"Sumar al pedido"*.
- Service: *"También imprimimos: apuntes, fotos, anillados. Consultanos."*
- Contest: *"Participá y ganá. Seguinos y etiquetá a un amigo."*

---

## VISUAL FOUNDATIONS

**Colors.** A tight, high-contrast 3-color brand — **Coke Red, Black C, Brilliant White** — extended into red and warm-neutral scales (see `colors_and_type.css`). Red is the identity and is used boldly: full-bleed red panels, red CTAs, red price flags. Black C is the warm ink (never pure black `#000`); Brilliant White `#F0F0F1` is the page surface (never pure `#fff` for large areas — pure white is reserved for raised cards). A single **promo yellow** `#FFD400` is allowed as a secondary pop on offer graphics / cartelera, echoing classic supermarket sale signage. Status colors (success green, warning amber, info blue) exist for app feedback only.

**Type.** Single-family system: **Exo 2** everywhere. Its slightly techy, rounded-geometric forms give the "modern + novel" feel the brand wants. Headlines and the logo lean on **ExtraBold/Black Italic** (the wordmark is italic) for speed and energy; body is Regular/Medium upright. Prices are ExtraBold Italic. Mono is used only for SKUs/codes.

**Spacing.** 4px base grid (`--sp-*`). Generous breathing room on light surfaces; promo graphics pack tighter for impact.

**Backgrounds.** Three modes: (1) **light** — Brilliant White page with white raised cards; (2) **bold red** — full-bleed Coke Red panels with white text for heroes, promos, headers; (3) **dark** — Black C surfaces for contrast moments. No gradients on brand surfaces (flat color is the rule); product photography is the imagery, shot bright and clean on white/red. A subtle **diagonal italic motion** (the logo's slant ≈ 8–10°) can be echoed in promo badges and price flags. No hand-drawn illustration; rely on real product photos + logo.

**Imagery vibe.** Bright, saturated, warm, well-lit product shots (bottles, cans, snacks) on clean white or red — supermarket-catalog energy, not moody. No B&W, no heavy grain.

**Animation.** Snappy and confident. Quick fades + small upward slides (8–12px) on enter; buttons use a subtle press-scale. Easing `cubic-bezier(.2,.7,.3,1)` (ease-out, slight overshoot allowed on badges). Durations 120–240ms. No long, floaty motion.

**Hover states.** Solid buttons darken (red → `--red-600`). Ghost/outline buttons fill on hover. Cards lift (`--shadow-md` → `--shadow-lg`) and may nudge up 2px. Links shift to `--accent`.

**Press states.** Buttons scale to `0.97` and deepen color (`--red-700`); no opacity-only presses.

**Borders.** Hairline `1px` in `--ink-300`. Inputs use `1.5px`, focusing to a 2px red ring (`--accent` at 35% via box-shadow). Promo elements may use a bold `3px` solid red/black outline for poster energy.

**Shadows.** Soft, warm-tinted (`rgba(45,41,38,…)`), three steps (sm/md/lg). Red CTAs may carry a red glow (`--shadow-red`). No inner shadows in normal UI.

**Radii.** Friendly but not bubbly: cards `--r-md`/`--r-lg` (12–18px), buttons `--r-md`, pills & chips `--r-pill`, price flags often near-square (`--r-xs`) with a notched/diagonal feel.

**Cards.** White surface, `--r-lg`, `1px` `--ink-300` border *or* `--shadow-sm` (not both heavy), 16–20px padding. Product cards: photo on white, name in Medium, price in ExtraBold Italic, red "Agregar" affordance.

**Transparency & blur.** Used lightly — sticky app headers use white at ~85% with `backdrop-filter: blur(10px)`; promo overlays may sit on a red panel at 90%. Avoid glassmorphism elsewhere.

**Layout rules.** App: fixed top header + fixed bottom tab bar (mobile-first). Promo placas: square (1080×1080) and story (1080×1920) with the logo locked to a corner and a clear-space margin equal to the height of the "K". Price/CTA always highest-contrast element.

---

## ICONOGRAPHY

The brand ships **no custom icon set**. For the app and digital materials this system standardizes on **[Lucide](https://lucide.dev)** (loaded from CDN) — clean, rounded, consistent 1.75–2px stroke icons that match Exo 2's friendly-geometric tone. Use line (stroke) icons by default; use Lucide's filled/duotone sparingly for active tab states.

- **Stroke weight:** 2px, `currentColor`, round caps/joins.
- **Common app icons:** `home`, `search`, `shopping-cart`, `user`, `map-pin`, `clock`, `tag`, `percent`, `flame` (ofertas), `snowflake` (hielo), `beer`, `printer` (servicios anexos), `truck`/`bike` (delivery), `credit-card`, `plus`, `minus`, `chevron-right`, `heart`.
- **Emoji:** allowed only on social *placas* (🛒🔥🧊🍻🎉), never as UI chrome.
- **Unicode chars as icons:** avoid; use Lucide.
- **Substitution flag:** Lucide is a substitution chosen by this system — the brand provided no icon library. Swap if the team adopts an official set.

Logo assets live in `assets/` (`logo-red.svg`, `logo-white.svg`, `logo-black.svg`). **Logo usage:** red on light backgrounds; white on red/dark backgrounds; black version for single-color/print constraints. Keep clear space ≥ height of the "K"; never recolor, stretch, or un-italicize.

---

## Files in this system (index)

| Path | What |
|---|---|
| `README.md` | This file — context, content, visual foundations, iconography, index |
| `colors_and_type.css` | All color + type tokens, `@font-face` (Exo 2), semantic type classes |
| `fonts/` | Self-hosted Exo 2 `.ttf` (Thin → Black, + italics) |
| `assets/` | Logos (`logo-red/white/black.svg`) |
| `preview/` | Design System tab cards (colors, type, spacing, components, brand) |
| `ui_kits/app/` | **Kiosco Enjoy ordering app** UI kit (React/JSX components + `index.html`) — interactive prototype |
| `ui_kits/placas/` | **Social promo placas / cartelera** kit (oferta, combo, sorteo, afiche templates) |
| `SKILL.md` | Agent Skill manifest for use in Claude Code |

> The `preview/` cards are also registered in the **Design System** tab (Colors, Type, Spacing, Components, Brand), as are both UI kit `index.html` files.

### Sources provided by the client
- `uploads/brandeo.pdf` — brand color sheet (Coke Red / Black C / Brilliant White, with CMYK·RGB·HEX).
- `uploads/kioscoenjoy_red_sf.svg`, `…_blanco_sf.svg`, `…_blackC_sf.svg` — logo color versions (red & white most used).
- `uploads/Exo2-*.ttf` — Exo 2 webfont family.
- Company description (products, brands, services, voice) — captured above.
